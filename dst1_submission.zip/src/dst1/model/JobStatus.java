package dst1.model;

public enum JobStatus {
	SCHEDULED,
	RUNNING,
	FAILED,
	FINISHED
}
